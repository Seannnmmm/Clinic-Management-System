
package login;


public class Appointment {
    private String patientName;
    private String patientNRIC;
    private String patientIllness;
    private String doctorName;
    private String appointmentDate;
    private String appointmentSlot;
    private String note;

    public Appointment(String patientName, String patientNRIC, String patientIllness, String doctorName, String appointmentDate, String appointmentSlot, String note) {
        this.patientName = patientName;
        this.patientNRIC = patientNRIC;
        this.patientIllness = patientIllness;
        this.doctorName = doctorName;
        this.appointmentDate = appointmentDate;
        this.appointmentSlot = appointmentSlot;
        this.note = note;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getPatientNRIC() {
        return patientNRIC;
    }

    public String getPatientIllness() {
        return patientIllness;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public String getAppointmentSlot() {
        return appointmentSlot;
    }

    public String getNote() {
        return note;
    }
}

