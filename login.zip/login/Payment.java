
package login;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.ArrayList;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
 

public class Payment extends JFrame {
    private JTable table;
    private JTextField userNameField;
    private JButton btn1, btn2, btn3, btn4, btn5;
    private Vector<Vector<Object>> originalData = new Vector<>(); // Store original data
    private Vector<String> columnNames = new Vector<>(); // Store column names
    String filepath = "/Users/sean/Documents/Admin/src/login/txtpayment.txt";

    public Payment() {
        setTitle("Appointment Management System");
        setSize(1200, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        
        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        
        //Create Table
        table = new JTable(); // Assuming you have a model to set
        table.setRowHeight(30);
        DefaultTableModel tableModel = new DefaultTableModel();
        table.setModel(tableModel);
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // No need to implement anything here for deletion,
                // but you need this listener to enable row selection.
            }
        });
        tablePanel.add(new JScrollPane(table), BorderLayout.CENTER);
        
        //Add columns to table
        tableModel.addColumn("Patient's Name");
        tableModel.addColumn("Doctor's Name");
        tableModel.addColumn("Appointment Date");
        tableModel.addColumn("Appointment Slot");
        tableModel.addColumn("Payment(RM)");
        tableModel.addColumn("Payment Date");
        tableModel.addColumn("Payment Method");
        tableModel.addColumn("Status");
        
        
        columnNames.add("Patient's Name");
        columnNames.add("Doctor's Name");
        columnNames.add("Appointment Date(EX:DD-MM-YYYY");
        columnNames.add("Appointment Slot(EX:00:00-00:30)");
        columnNames.add("Payment(RM)");
        columnNames.add("Payment Date(EX:DD-MM-YYYY)");
        columnNames.add("Payment Method");
        columnNames.add("Status");
        

        //Read data
        try(BufferedReader br = new BufferedReader(new FileReader(filepath))){
            String line;
            while((line = br.readLine()) != null){
                String[] data = line.split(",");
                tableModel.addRow(data);
                Vector<Object> dataRow = new Vector<>();
                for(String item : data) {
                    dataRow.add(item);
                }
                originalData.add(dataRow);
        }
            }
          catch (FileNotFoundException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //Page Title
        JLabel pageTitle = new JLabel("Payment Management System");
        pageTitle.setFont(new Font("Segoe UI",Font.BOLD,36));
        
        //UserID Text Field
        userNameField = new JTextField(10);
        userNameField.setPreferredSize(new Dimension(userNameField.getPreferredSize().width, 44));
        JLabel userNameLabel = new JLabel("Patient's Name:");
        userNameLabel.setFont(new Font("Segoe UI",Font.BOLD,16));
        
        //Top Panel
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.LINE_AXIS));
        topPanel.add(pageTitle);
        topPanel.add(Box.createHorizontalGlue());
        
        // Create a panel for right-aligned components
        JPanel topRightPanel = new JPanel();
        topRightPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 0, 0)); // No gaps
        topRightPanel.add(userNameLabel);
        topRightPanel.add(userNameField);

        // Ensure the rightPanel doesn't dictate the size too much
        topRightPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, topRightPanel.getPreferredSize().height));

        // Add the right-aligned panel to topPanel
        topPanel.add(topRightPanel);

        // Add topPanel to tablePanel at the NORTH position
        tablePanel.add(topPanel, BorderLayout.NORTH);

        // Buttons Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btn1 = new JButton("+Make New Payment");
        btn2 = new JButton("View");
        btn3 = new JButton("Edit");
        btn4 = new JButton("Delete");
        btn5 = new JButton("Go Back");
        
        buttonPanel.add(btn1);
        buttonPanel.add(btn2);
        buttonPanel.add(btn3);
        buttonPanel.add(btn4);
        buttonPanel.add(btn5);
        
        //Button Styling
        btn1.setBackground(new Color(0,102,102));
        btn1.setForeground(Color.black);
        btn1.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn1.setPreferredSize(new Dimension(btn1.getPreferredSize().width, 42));
        
        btn2.setBackground(new Color(0,102,102));
        btn2.setForeground(Color.black);
        btn2.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn2.setPreferredSize(new Dimension(btn2.getPreferredSize().width,42));
        
        btn3.setBackground(new Color(0,102,102));
        btn3.setForeground(Color.black);
        btn3.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn3.setPreferredSize(new Dimension(btn3.getPreferredSize().width, 42));
        
        btn4.setBackground(new Color(0,102,102));
        btn4.setForeground(Color.black);
        btn4.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn4.setPreferredSize(new Dimension(btn4.getPreferredSize().width, 42));
        
        btn5.setBackground(new Color(0,102,102));
        btn5.setForeground(Color.black);
        btn5.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn5.setPreferredSize(new Dimension(btn5.getPreferredSize().width, 42));
        
        btn1.addActionListener(e -> addNewUser());
        btn2.addActionListener(e -> viewUser());
        btn3.addActionListener(e -> editUser());
        btn4.addActionListener(e -> deleteUser());
        btn5.addActionListener(e -> goback());
       

        // Add panels to frame
        add(tablePanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Action Listener for userIdField
        userNameField.addActionListener(e -> fetchUserRecord(userNameField.getText()));

        setVisible(true);
    }

    Payment(String userUsername) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void fetchUserRecord(String userName) {
    userName = userName.toUpperCase();

    if (userName.isEmpty()) {
        loadOriginalData(); // If userName is empty, load original data
        return;
    }

    DefaultTableModel originalTableModel = (DefaultTableModel) table.getModel();
    // Create a new table model for filtered results
    DefaultTableModel filteredModel = new DefaultTableModel();
    
    // Copy column names from the original model to the filtered model
    for (int i = 0; i < originalTableModel.getColumnCount(); i++) {
        filteredModel.addColumn(originalTableModel.getColumnName(i));
    }
    
    // Iterate through the original table to find and add the matching rows to the filtered model
    boolean recordFound = false;
    for (int row = 0; row < originalTableModel.getRowCount(); row++) {
        String currentUserName = String.valueOf(originalTableModel.getValueAt(row, 0)); // Assuming User Name is in the second column
        if (currentUserName.equalsIgnoreCase(userName)) {
            // User found, add this row to the filtered model
            recordFound = true;
            Object[] rowData = new Object[originalTableModel.getColumnCount()];
            for (int col = 0; col < originalTableModel.getColumnCount(); col++) {
                rowData[col] = originalTableModel.getValueAt(row, col);
            }
            filteredModel.addRow(rowData);
        }
    }
    
    if (recordFound) {
        // Set the filtered model to the table
        table.setModel(filteredModel);
    } else {
        JOptionPane.showMessageDialog(null, "Patient's Name " + userName + " not found.", "Record Not Found", JOptionPane.WARNING_MESSAGE);
    }
}


    private void loadOriginalData() {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // Clear existing data
        for (Vector<Object> row : originalData) {
            model.addRow(row);
        }
    }

    private void addNewUser() {
        JFrame addFrame = new JFrame("MAKE NEW PAYMENT");
        addFrame.setSize(600, 600);
        addFrame.setLayout(new GridLayout(0, 2)); // Simple grid layout for labels and text fields
    
        // Create and populate text fields for each user attribute
        JTextField[] textFields = new JTextField[columnNames.size()];
        for (int i = 0; i < columnNames.size(); i++) {
            JLabel label = new JLabel(columnNames.get(i) + ": ");
            label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
            textFields[i] = new JTextField();
            addFrame.add(label);
            addFrame.add(textFields[i]);
        }
    
        JButton saveButton = new JButton("SAVE");
        addFrame.add(saveButton);
        saveButton.addActionListener(e -> {
            // Create a new row with the user data
            Vector<Object> newRow = new Vector<>();
            for (JTextField textField : textFields) {
                newRow.add(textField.getText());
            }
    
            // Add the new row to the original data and table model
            originalData.add(newRow);
            ((DefaultTableModel) table.getModel()).addRow(newRow);
    
            // Append the new user data to the text file
            try (PrintWriter writer = new PrintWriter(new FileWriter(filepath, true))) {
                for (int i = 0; i < newRow.size(); i++) {
                    writer.print(newRow.get(i));
                    if (i < newRow.size() - 1) writer.print(",");
                }
                writer.println();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
    
            addFrame.dispose(); // Close the add window
            JOptionPane.showMessageDialog(null, "Payment added successfully.");
        });
    
        addFrame.setLocationRelativeTo(null); // Center the window
        addFrame.setVisible(true);
    }
    
    private void viewUser() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            JFrame viewFrame = new JFrame("VIEW PAYMENT");
            viewFrame.setSize(600, 400);
            //viewFrame.setLayout(new BorderLayout(10, 10)); // Use BorderLayout for better control
    
            // Panel to hold user data labels
            JPanel userDataPanel = new JPanel();
            userDataPanel.setLayout(new BoxLayout(userDataPanel, BoxLayout.Y_AXIS));
            userDataPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add some padding
            userDataPanel.setBackground(Color.white); // Set a light gray background
    
            // Title label
            JLabel titleLabel = new JLabel("Payment Details");
            titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0)); // Bottom margin for the title
            userDataPanel.add(titleLabel);
    
            // For each column, create a JLabel and add it to the panel
            for (int i = 0; i < table.getColumnCount(); i++) {
                String columnName = table.getColumnName(i);
                Object value = table.getValueAt(selectedRow, i);
                JLabel userData = new JLabel(columnName + ": " + value);
                userData.setFont(new Font("Segoe UI", Font.BOLD, 16));
                userData.setHorizontalAlignment(JLabel.CENTER);
                userDataPanel.add(userData);
            }

            viewFrame.add(userDataPanel); // Add the centering panel to the frame
            viewFrame.setLocationRelativeTo(null); // Center the window
            viewFrame.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Please select a payment to view.");
        }
    }
    
    private void editUser() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            JFrame editFrame = new JFrame("EDIT PAYMENT");
            editFrame.setSize(600, 600);
            editFrame.setLayout(new GridLayout(0, 2)); // Simple grid layout for labels and text fields
    
            // Create and populate text fields for each user attribute
            JTextField[] textFields = new JTextField[columnNames.size()];
            for (int i = 0; i < columnNames.size(); i++) {
                JLabel label = new JLabel(columnNames.get(i) + ": ");
                label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
                textFields[i] = new JTextField(String.valueOf(table.getValueAt(selectedRow, i)));
                editFrame.add(label);
                editFrame.add(textFields[i]);
            }
    
            JButton saveButton = new JButton("SAVE");
            editFrame.add(saveButton);
            saveButton.addActionListener(e -> {
                // Update the originalData and table model with new user data
                Vector<Object> newData = new Vector<>();
                for (JTextField textField : textFields) {
                    newData.add(textField.getText());
                }
                originalData.set(selectedRow, newData);
    
                // Update the table model directly (for immediate UI update)
                DefaultTableModel model = (DefaultTableModel) table.getModel();
                for (int i = 0; i < newData.size(); i++) {
                    model.setValueAt(newData.get(i), selectedRow, i);
                }
    
                // Rewrite the text file with updated data
                try (PrintWriter writer = new PrintWriter(new FileWriter(filepath))) {
                    for (Vector<Object> row : originalData) {
                        for (int i = 0; i < row.size(); i++) {
                            writer.print(row.get(i));
                            if (i < row.size() - 1) writer.print(",");
                        }
                        writer.println();
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
    
                editFrame.dispose(); // Close the edit window
                JOptionPane.showMessageDialog(null, "Payment updated successfully.");
            });
    
            editFrame.setLocationRelativeTo(null); // Center the window
            editFrame.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Please select a payment to edit.");
        }
    }
    
    private void deleteUser() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            // Confirm before deleting
            int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this payment?", "Delete Payment", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                List<String> lines = new ArrayList<>();
            try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    lines.add(line);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            // Step 2: Remove the selected entry
            if (selectedRow < lines.size()) { // Check to avoid IndexOutOfBoundsException
                lines.remove(selectedRow);
            }

            // Step 3: Write the updated list back to the file
            try (PrintWriter writer = new PrintWriter(new FileWriter(filepath))) {
                for (String line : lines) {
                    writer.println(line);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            // Finally, remove the row from the table model
            ((DefaultTableModel) table.getModel()).removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Payment deleted successfully.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please select a payment to delete.");
        }
    }
    
    private void goback() {
        AdminDashboard management = new AdminDashboard();
        management.setVisible(true);
        this.dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Payment::new);
    }
}

